#!/bin/bash

ruby node.rb nodes-to-addrs.txt addrs-to-links.txt


 
